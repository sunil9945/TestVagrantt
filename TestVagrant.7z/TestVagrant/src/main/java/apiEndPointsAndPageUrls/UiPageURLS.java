package apiEndPointsAndPageUrls;

public class UiPageURLS {
	
	static public String weather = "https://social.ndtv.com/static/Weather/report/";

}
