package apiEndPointsAndPageUrls;

public class ApiPath {

	public static final class apiPath {

		// GET
		public static final String GET_WEATHER = "weather";

	}

}
