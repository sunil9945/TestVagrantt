package utils;

public class ApiKeys {

	public static final class apiKey {

		public static final String GET_WEATHER = "7fe67bf08c80ded756e598d6f8fedaea";
	}
}